# Inflated Expectations

**Christopher Gandrud and Cassandra Grafström**

These files comprise the replication material (figures + analyses) for the paper ''[Inflated Expectations: How government partisanship shapes 
bureaucrats' inflation expectations](http://ssrn.com/abstract=2125283)''.

The paper has been conditionally accepted at [Political Science
Research and Methods](http://journals.cambridge.org/action/displayJournal?jid=RAM).

## About

Governments' party identifications can indicate the types of economic
policies they are likely to pursue. A common rule of thumb is that
left-party governments are expected to pursue policies for lower
unemployment, but which may cause inflation. Right-party governments
are expected to pursue lower inflation policies. How do these
expectations shape the inflation forecasts of monetary policy
bureaucrats? If there is a mismatch between the policies bureaucrats
*expect* governments to implement and those that they *actually* do,
forecasts will be systematically biased. Using US Federal Reserve
Staff’s forecasts we test for executive partisan biases. We find that
irrespective of actual policy and economic conditions forecasters
systematically overestimate future inflation during left-party presidencies
and underestimate future inflation during right-party ones. Our findings
suggest that partisan heuristics play an important part in monetary
policy bureaucrats' inflation expectations.

## Reproduce the paper (including analyses, plots, and tables)

To reproduce the entire text of the paper including the body, figures, analyses, and tables please follow the instructions at: 
<https://github.com/christophergandrud/GreenBook>

## Reproduce only the analyses and plots

The **R** source code and data for replicating the analyses and plots is in this DVN repository. We used R version 3.1.0.

To reproduce the figures and all of the analyses:

1. Install the necessary R packages using the following code:

```{S}
install.packages("apsrtable", "knitr", "ggplot2", "gridExtra", "DataCombine",
                "devtools", "MatchIt", "MCMCpack", "plotrix", "plyr",
                "repmis", "reshape2", "stringr", "xtable", "Zelig")
```

2. Change the working directory in `Greenbook1.R` line 10 as 
appropriate.

3. The source code files must be run in the sequence in which they appear in  
paper. Start with the file called *Greenbook1.R*. This will load the data set
and create the first plot in the paper. The files' suffixes indicate the order in which to run them.

The data set we used in the paper is called
*GB_FRED_cpi_2007.csv*. The *README_data.html* file contains variable desciptions.