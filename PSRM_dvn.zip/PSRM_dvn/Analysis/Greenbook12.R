###############
# Propensity score distribution plots
# Christopher Gandrud
# 9 May 2014
###############

# Load package
library(MatchIt)

#### Create plots ####
# Matched by election period
plot(cpi.matched.election, type = "jitter", interactive = FALSE)

# Matched by presidential party ID
plot(cpi.matched.party, type = "jitter", interactive = FALSE)
